package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckOut {
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/label[2]")
 WebElement card;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[1]/div[1]/label/span[2]/input")
 WebElement FullName;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[1]/div[2]/label/span[2]/input")
 WebElement email;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[1]/div[3]/label/span[2]/input")
 WebElement telephone;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[2]/div[1]/div[1]/label/span[2]/input")
  WebElement CardNumber;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[2]/div[2]/div[1]/label/span[2]/input")
 WebElement expiryDate;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[2]/div[2]/div[2]/label/span[2]/input")
 WebElement CVV;
 
 @FindBy(xpath="//*[@id='mainForm']/div[4]/div[2]/main/div/section[2]/fieldset[2]/div[3]/div[1]/button")
 WebElement completeBooking;
 
 
 
 public void Payment() throws InterruptedException
 {
	 selectDebitCreditCard();
	 Thread.sleep(1000);
	 setName();
	 Thread.sleep(1000);
	 setEmail();
	 Thread.sleep(1000);
	 setTelephone();
	 Thread.sleep(1000);
	 setCardNumber();
	 Thread.sleep(1000);
	 setExpiry();
	 Thread.sleep(1000);
	 Submit();
	 Thread.sleep(1000);

 }
 public void selectDebitCreditCard()
 {
	 card.click();
	 
 }
 
 public void setName()
 {
	FullName.sendKeys("abc"); 
}
 
 public void setEmail()
 {
	 email.sendKeys("abc@gmail.com");
 }
 
 public void setTelephone()
 {
	 telephone.sendKeys("87878787878");
 }
 
 public void setCardNumber()
 {
	 CardNumber.sendKeys("4242 4242 4242 4242");
 }
 
 public void setExpiry()
 {
	 expiryDate.sendKeys("03/22");
 }
 
 public void setCVV()
 {
	 CVV.sendKeys("100");
 }
 
 public void Submit()
 {
	 completeBooking.submit();
 }
 }
