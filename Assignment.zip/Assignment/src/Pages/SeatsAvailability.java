package Pages;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.FindBy;

public class SeatsAvailability {
	  WebDriver driver;
	  
	  @FindBy(xpath="//div[contains(@class,'seat-plan__content')]")
	  WebElement Seats;
	  
	  
	  @FindBy(xpath="//*[contains(text(),'Front row - will need to look up due to the height of the stage')]")
	  WebElement cRow;
	  public SeatsAvailability(WebDriver driver)
	  {
		  this.driver=driver;
	  }
	  
	  
	 public void selectSeats() throws InterruptedException, IOException
	 {
		 System.out.println("getting all available seats");

		 System.out.println(Seats.getAttribute("src"));
		 File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 FileHandler.copy(scrFile, new File("D:\\Selenium\\Canvastest.png"));
		 
		 Actions builder=new Actions(driver);
		  
		 WebElement seat_tooltip=driver.findElement(By.xpath("//*[@id='PlanCanvas']"));
		  
		 builder.moveToElement(seat_tooltip,135,186).click().build().perform();
		  
		 String seat_msg=seat_tooltip.getText();
		  
		  System.out.println("selected seat is "+seat_msg);


		 
	 }

	  
 
}
