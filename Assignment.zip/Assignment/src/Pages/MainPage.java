package Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class MainPage {
	WebDriver driver;
	
	@FindBy(className="musicals")
	WebElement Musicals;
	
	@FindBy(xpath="//*[@id='ctl00_MainContent_MusicalsContainer_EventList_ctrl25_ctl00_EventHl']")
	
	WebElement MammaMiaShow;
	
	public void goToMusicals()
	{
		Musicals.click();
	}
	
	public void MummaMiaShow(){
	
	MammaMiaShow.click();
		
	}
  
 
}
