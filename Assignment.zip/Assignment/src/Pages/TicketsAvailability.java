package Pages;


import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;


public class TicketsAvailability {
	 WebDriver driver;
	 String expectedMonth="December";
	 String expectedDay="2";

 
   @FindBy(xpath="//ul[@id='ctl00_ctl00_MainContent_MainContent_CalendarMonthsList']")
   List<WebElement> list_AllMonthToBook;
 
 @FindBy(xpath="//*[@id='ctl00_ctl00_MainContent_MainContent_CalendarSection']")
 List<WebElement> list_AllDayToBook;

 @FindBy(xpath="//div/div/div/div/a/span/strong[contains(text(),'7.45pm')]")
 
 WebElement show2;
 
 @FindBy(xpath="//div/div/div/div/a/span/strong[contains(text(),'3pm')]")
 WebElement show1;
 
 public TicketsAvailability(WebDriver driver) {
	
	  this.driver=driver;
 }
 
 public void selectMonthDate() throws InterruptedException
 {
	
	
	 for( int i=0;i<list_AllMonthToBook.size();i++)
	 {
		 String MM=list_AllMonthToBook.get(i).getText();
		 
		 System.out.println(MM);
		 
		 if(MM.contains(expectedMonth))
		 {
			 list_AllMonthToBook.get(i).click();
			 System.out.println("selected month is "+list_AllMonthToBook.get(i).getText());
			 break;
			
		 }
	 }
			 
		 for (WebElement date: list_AllDayToBook)
		 {
			 
			
			 String date1=date.getText();
			 System.out.println(date1);

			 if(date1.contains(expectedDay))
			 {
				 date.click();
				 if(date1.contains("7.45pm")&& date1.contains("3pm"))
				 {
				 					
					 Thread.sleep(2000);
				     show2.click();
				 }
				 else
				 {
					 Thread.sleep(2000);
					 show1.click(); 
				 } 
			 }
			
	 }
	 
	 
		 
 }

}
