package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class MammaMiaTickets {
	WebDriver driver;
	
@FindBy(xpath="//*[@id='ctl00_MainContent_BookingBoxControl_BookButtonHL']/span")
WebElement bookTickets;

public MammaMiaTickets(WebDriver driver)
{
	this.driver=driver;
}

public void bookTickets()
{
	bookTickets.click();
}

}
