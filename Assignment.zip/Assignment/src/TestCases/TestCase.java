package TestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Pages.CheckOut;
import Pages.MainPage;
import Pages.MammaMiaTickets;
import Pages.SeatsAvailability;
import Pages.TicketsAvailability;


public class TestCase {
	
	public WebDriver driver;

	
	
	@BeforeSuite
	public void setup() throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	
	}
	
/*-------------------------Launch URL-----------------------------------------------------------------*/
	
	@Test()
	public void LaunchUrl() throws AssertionError, InterruptedException
	{
		
		
		try{
			driver.get("https://www.londontheatredirect.com/");
			Thread.sleep(1000);
			String pageName = driver.getTitle();
			Assert.assertEquals("London Theatre Tickets � London Shows | London Theatre Direct",pageName);
			System.out.println("url launched successfully");
		    
			}
			catch(AssertionError e)
			{
				System.out.println("something wrong with url"+e.getMessage());
				Assert.fail("*********TEST CASE FAIL******");
				
			}
			
	}
	
	/*-------------------------Select Mamma Mia Show--------------------------*/
	
	@Test(dependsOnMethods="LaunchUrl")
	public void selectShow() throws InterruptedException
	{
		MainPage page=PageFactory.initElements(driver, MainPage.class);
		page.goToMusicals();
		Thread.sleep(1000);
		
		try{
		page.MummaMiaShow();
		Assert.assertEquals(driver.getTitle(), "Mamma Mia! Tickets - Musical Tickets | London Theatre Direct");
		}
		catch(AssertionError e)
		{
			System.out.println("such show not available"+e.getMessage());
			Assert.fail("TEST CASE FAIL******");
		}
		
		
	}
	
	/*----------------------------Book Tickets----------------------------*/
	
	@Test(dependsOnMethods="selectShow")
	public void bookShow() throws InterruptedException
	{
		MammaMiaTickets tickets=PageFactory.initElements(driver, MammaMiaTickets.class);
		tickets.bookTickets();
		
		Thread.sleep(1000);
		
		TicketsAvailability tick=PageFactory.initElements(driver, TicketsAvailability.class);
		tick.selectMonthDate();
		Thread.sleep(1000);
	
		
	}
	
	/*------------------------------Select different colored seats (multiple)--------------*/
	@Test(dependsOnMethods="bookShow")
	public void SelectSeats() throws InterruptedException
	{
		
		SeatsAvailability seatAvailable=PageFactory.initElements(driver, SeatsAvailability.class);
		Thread.sleep(3000);
		try{
		seatAvailable.selectSeats();
		Thread.sleep(3000);
		}
		catch (Exception e) {
			System.out.println("Unable to select seat"+e.getMessage());
		}
		

		
		
	}
	
	/*----------------------------Complete Payment---------------------*/
	
	@Test(dependsOnMethods="SelectSeats")
	public void BookingCompletion() throws InterruptedException
	{
		CheckOut checkout=PageFactory.initElements(driver, CheckOut.class);
		try{
			checkout.Payment();
			Thread.sleep(1000);
		}
		catch (Exception e){
			System.out.println("Something went wrong with payment page"+ e.getMessage());

		}
		
		
	}
	
	
	@AfterSuite
	public void CloseWindow()
	{
		driver.quit();
	}
	
	
}
